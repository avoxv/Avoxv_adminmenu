fx_version 'cerulean'
game      'gta5'

name        'avoxv_recoil'
description 'Realistic Recoil – Screen Shake + Barrel Rise, Ramps With Sustained Fire'
author      'Avoxv'
version     '1.0.0'

shared_scripts {
    '@es_extended/imports.lua',
    'config.lua',
}

client_scripts {
    'client/client.lua',
}

local ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

local bulletCount    = 0
local lastShotTime   = 0
local lastWeapon     = nil
local shakeEndTime   = 0

local function IsWeaponAffected(weaponHash)
    if Config.WeaponMode == 'all' then
        return true
    end

    local inList = false
    for _, name in ipairs(Config.WeaponList) do
        if GetHashKey(name) == weaponHash then
            inList = true
            break
        end
    end

    if Config.WeaponMode == 'whitelist' then return inList end
    if Config.WeaponMode == 'blacklist' then return not inList end
    return true
end

local function GetRecoilValues()
    local stage = math.max(0, bulletCount - 1)  -- 0-indexed stage

    local pitch = math.min(
        Config.BasePitch + (stage * Config.PitchIncrement),
        Config.MaxPitch
    )

    local yawMag = math.min(
        Config.BaseYaw + (stage * Config.YawIncrement),
        Config.MaxYaw
    )
    local yaw = (math.random() * 2.0 - 1.0) * yawMag

    local shake = math.min(
        Config.ShakeIntensity + (stage * Config.ShakeIncrement),
        Config.MaxShake
    )

    return pitch, yaw, shake
end

local function ApplyRecoil()
    local pitch, yaw, shake = GetRecoilValues()

    local currentPitch = GetGameplayCamRelativePitch()
    local newPitch = math.max(
        Config.PitchClampMin,
        math.min(Config.PitchClampMax, currentPitch - pitch)
    )
    SetGameplayCamRelativePitch(newPitch, 1.0)

    local currentYaw = GetGameplayCamRelativeHeading()
    SetGameplayCamRelativeHeading(currentYaw + yaw)

    SetGameplayCamShakeAmplitude(shake)
    ShakeGameplayCam('HAND_SHAKE', shake)
    shakeEndTime = GetGameTimer() + Config.ShakeDurationMs
end

CreateThread(function()
    while true do
        Wait(0)

        local ped = PlayerPedId()

        if IsPedDeadOrDying(ped, true) or IsPauseMenuActive() then
            bulletCount  = 0
            lastWeapon   = nil
            goto continue
        end

        local weaponHash = GetSelectedPedWeapon(ped)
        if weaponHash ~= lastWeapon then
            lastWeapon  = weaponHash
            bulletCount = 0
        end

        local now = GetGameTimer()

        if IsPedShooting(ped) and IsWeaponAffected(weaponHash) then
            if (now - lastShotTime) >= Config.ShotDebounceMs then
                lastShotTime = now
                bulletCount  = bulletCount + 1
                ApplyRecoil()
            end
        else
            if now > shakeEndTime and shakeEndTime ~= 0 then
                StopGameplayCamShaking(true)
                shakeEndTime = 0
            end
            if (now - lastShotTime) >= Config.ResetAfterMs and bulletCount > 0 then
                bulletCount = 0
            end
        end

        ::continue::
    end
end)

if Config.Debug then
    RegisterCommand('recoilinfo', function()
        local ped        = PlayerPedId()
        local weapon     = GetSelectedPedWeapon(ped)
        local p, y, s    = GetRecoilValues()
        print(string.format(
            '[esx_recoil] Bullet#%d | Weapon=0x%X | Pitch=%.2f Yaw=%.2f Shake=%.2f | Affected=%s',
            bulletCount, weapon, p, y, s, tostring(IsWeaponAffected(weapon))
        ))
    end, false)
end

Config = {}

Config.Debug = false
Config.RecoilStartBullet = 1
Config.BasePitch          = 0.00
Config.PitchIncrement     = 0.0
Config.MaxPitch           = 0.0
Config.BaseYaw            = 0.0
Config.YawIncrement       = 0.0
Config.MaxYaw             = 0.0

Config.ShakeIntensity     = 54.00  -- base screen shake per shot
Config.ShakeIncrement     = 54.00  -- grows slightly with sustained fire
Config.MaxShake           = 54.00  -- hard cap
Config.ShakeDurationMs    = 80    -- how long each shake lasts (ms)

Config.ShotDebounceMs     = 75    -- debounce so one pull = one bullet tick
Config.ResetAfterMs       = 500   -- idle time before bullet counter resets

Config.PitchClampMin      = -89.0
Config.PitchClampMax      =  89.0

-- 'all'       = every weapon
-- 'blacklist' = all weapons EXCEPT those listed
-- 'whitelist' = ONLY weapons listed
Config.WeaponMode = 'blacklist'

Config.WeaponList = {
    'WEAPON_SNIPERRIFLE',
    'WEAPON_HEAVYSNIPER',
    'WEAPON_HEAVYSNIPER_MK2',
    'WEAPON_MARKSMANRIFLE',
    'WEAPON_MARKSMANRIFLE_MK2',
    'WEAPON_REMOTESNIPER',
    'WEAPON_MINIGUN',
    'WEAPON_RAILGUN',
    'WEAPON_HOMINGLAUNCHER',
    'WEAPON_RPGLAUNCHER',
    'WEAPON_RPGLAUNCHER_2',
    'WEAPON_GRENADELAUNCHER',
    'WEAPON_GRENADELAUNCHER_SMOKE',
    'WEAPON_COMPACTLAUNCHER',
    'WEAPON_FIREWORK',
}
